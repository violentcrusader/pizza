print ('Hello World')

sauce = 'tomato'

description = """
What are you doing with these pizza,
random text to show that you can stor big texts in variables
"""

order_number = 42

order_number = 'not a number anymore'

if sauce.startswith('toma'):
    print("It's probably a tomato...")
else:
    print("not tomato")

print description
