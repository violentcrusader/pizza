
class Pedidos(object):
    def __init__(self, nome, endereco, obs): # criacao da instancia, incializacao dos atributos
        self.nome = nome
        self.endereco = endereco
        self.obs = obs
    
    
